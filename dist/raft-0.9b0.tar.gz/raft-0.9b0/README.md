RAFT - Reproducible Analysis Framework and Tools
